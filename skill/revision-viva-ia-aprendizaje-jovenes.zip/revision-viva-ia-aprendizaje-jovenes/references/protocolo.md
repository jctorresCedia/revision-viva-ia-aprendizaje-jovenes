# Protocolo · Revisión viva: impacto de la IA en las capacidades de aprendizaje de jóvenes

**Versión:** 1.1 · **Fecha de inicio:** 2026-10-10 · **Responsables:** Anai Oñate (AO), Juan Carlos Torres (JCT)

## Pregunta
¿Cuál ha sido el impacto del uso de herramientas de inteligencia artificial (IA generativa, chatbots, tutores inteligentes, sistemas adaptativos) en las capacidades de aprendizaje de adolescentes y jóvenes?

## Criterios de inclusión
- **Población:** adolescentes y jóvenes de 12 a 29 años (secundaria/bachillerato y educación superior).
- **Exposición:** uso de herramientas de IA por los propios estudiantes o jóvenes para aprender.
- **Resultados:** rendimiento o logro académico, aprendizaje de contenidos, pensamiento crítico, resolución de problemas, escritura, autorregulación, metacognición, motivación y compromiso, creatividad, dependencia o descarga cognitiva.
- **Tipo:** artículos académicos en revistas, con DOI registrado en Crossref como `journal-article`; estudios empíricos (cuantitativos, cualitativos, mixtos), revisiones sistemáticas y metaanálisis.
- **Años:** 2020 en adelante. **Idiomas:** inglés y español.

## Criterios de exclusión
Libros, capítulos, tesis, actas, preprints y depósitos de repositorio (p. ej., DOI de Zenodo), editoriales, revisiones narrativas y ensayos sin datos; IA usada solo por docentes o instituciones sin efectos medidos en el aprendizaje; poblaciones exclusivamente menores de 12 o mayores de 29 años; registros sin DOI.

## Fuentes y búsqueda
- **Fuentes declaradas:** Scopus, Redalyc, SciELO, Google Académico.
- **Motor automático:** OpenAlex (agrega Crossref, SciELO, Redalyc, DOAJ y repositorios) con verificación del tipo en Crossref. Google Académico no ofrece API y no se consulta automáticamente. La indexación en Scopus no puede comprobarse sin clave institucional: queda en la columna `verificar_scopus`.
- **Cadenas** (campo título + resumen; versión exacta en `config.json`):
  - ES (5 por lote): ("inteligencia artificial" OR "IA generativa" OR ChatGPT OR chatbot OR "tutor inteligente") AND (aprendizaje OR "rendimiento académico" OR "pensamiento crítico" OR habilidades OR competencias OR escritura) AND (estudiantes OR jóvenes OR adolescentes OR universitarios OR bachillerato)
  - EN (completa hasta 15): ("artificial intelligence" OR "generative AI" OR ChatGPT OR "large language model" OR chatbot OR "intelligent tutoring") AND ("learning outcomes" OR "academic performance" OR "academic achievement" OR "critical thinking" OR "learning performance" OR "self-regulated learning" OR "problem solving" OR "writing skills" OR metacognition OR "cognitive offloading") AND (students OR adolescents OR youth OR "young people" OR undergraduates OR "high school" OR "secondary school")
- **Filtros:** type:article, con DOI, no retractado, no paratexto, idioma es/en, publicación desde 2020-01-01.

## Lotes y calendario
- **15 artículos nuevos por lote**: hasta 6 publicados desde 14 días antes del lote anterior (novedades); el resto, de la búsqueda acumulada por orden de relevancia.
- **Revisión humana:** cada sábado hasta las 21:00 (Ecuador, UTC-5) en la pestaña *Pendientes*.
- **Actualización automática:** cada sábado a las 22:00 (Ecuador).
- Cada lote exportado se guarda con fecha en `lotes/lote_<fecha>.csv`.

## Decisión
Cada revisor marca *Aprobar* o *Rechazar* y anota el motivo. Regla de consenso **AMBOS**: un registro pasa a *Aprobados* o *Rechazados* solo si los dos coinciden; si falta uno, sigue en *Pendientes*; si discrepan, queda en *Desacuerdo - conciliar*. La sugerencia de la IA es orientativa y se basa solo en el resumen.

## Registro de versiones
| Versión | Fecha | Cambio |
|---|---|---|
| 1.0 | 2026-10-10 | Protocolo inicial (lote de 25). |
| 1.1 | 2026-10-10 | Lote fijo de 15 (5 ES + 10 EN); solo DOI de Crossref `journal-article`. |
| 1.2 | 2026-10-10 | Scopus (API de Elsevier) como fuente: hasta 3 ES + 7 EN por lote salen de Scopus y el resto de OpenAlex; cada DOI se verifica en Scopus (columna `verificar_scopus`). Si la API no responde, el lote se completa con OpenAlex y se anota en *Lotes*. Cadenas Scopus en `config.json` (`cadena_scopus`). |
| 1.1 | 2026-10-10 | Confirmado por Anai Oñate: consenso de ambos revisores, población de 12 a 29 años, artículos desde 2020. |
