# Procedimiento semanal (sábado 22:00, hora de Ecuador)

Carpeta raíz: `G:\Mi unidad\Revision_Viva_IA_Aprendizaje_Jovenes`. Libro: `Revision_Viva_IA_Aprendizaje_Jovenes.xlsx`.
Pestañas: Instrucciones · Protocolo · Pendientes · Aprobados · Rechazados · Historial_cambios · Lotes.
`<F>` = fecha del día en formato `yyyy-MM-dd`. Ejecute cada script con:
`powershell -NoProfile -ExecutionPolicy Bypass -File "G:\Mi unidad\Revision_Viva_IA_Aprendizaje_Jovenes\scripts\<script>" -Fecha <F>`

Reglas que nunca se rompen
- La IA **no** aprueba ni rechaza: solo sugiere. Las decisiones vienen de las columnas `decision_JCT` y `decision_AO`.
- No edite el libro a mano ni con otro método que no sean los scripts. No borre filas.
- La deduplicación la hacen los scripts; no la rehaga.
- Si un script falla porque el libro está abierto o bloqueado, espere 10 minutos y reintente (máximo 3 veces); si sigue fallando, detenga el proceso e informe.

## Paso A · Consolidar decisiones
Ejecute `1_consolidar_decisiones.ps1`. Mueve los registros decididos por ambos revisores a Aprobados o Rechazados (con revisores, motivos y fecha) y escribe `trabajo\aprobados_nuevos_<F>.json`.

## Paso B · Buscar e importar el lote nuevo (15 artículos)
1. Ejecute `2_buscar_lote.ps1`. Genera `lotes\lote_<F>.csv` y `trabajo\candidatos_<F>.json`. Si responde `YA_EXISTE`, el lote de hoy ya se importó: omita el resto del paso B y el paso C y vaya al informe.
2. Lea `trabajo\candidatos_<F>.json` y `protocolo.md`. Para **cada** candidato escriba una sugerencia en `trabajo\sugerencias_<F>.json` (UTF-8), un arreglo JSON de objetos:
   `{"doi": "...", "sugerencia_IA": "Incluir" | "Excluir" | "Evidencia insuficiente", "justificacion_IA": "dos frases en español que apliquen los criterios del protocolo", "cita_del_resumen": "fragmento textual copiado del resumen"}`
   - Use solo el título y el resumen proporcionados; no invente datos.
   - Si el resumen dice «SIN RESUMEN DISPONIBLE», la sugerencia es «Evidencia insuficiente» y la cita queda vacía.
   - Excluya revisiones narrativas, ensayos sin datos, estudios centrados en docentes y poblaciones fuera de 12 a 29 años; señale los casos límite en la justificación.
3. Ejecute `3_agregar_pendientes.ps1`. Agrega los 15 registros a Pendientes y exporta `historial\historial_<F>.csv`.

## Paso C · Síntesis de los artículos aprobados esta semana
Si `trabajo\aprobados_nuevos_<F>.json` no está vacío:
1. Para cada artículo, abra el enlace DOI y, si existe, la URL de acceso abierto (columna `acceso_abierto`). Verifique que título, autores y año coincidan con el registro.
2. Escriba una síntesis breve (2 a 3 frases): diseño, muestra, hallazgo principal. Indique la base: «Texto completo (URL)» si leyó el artículo completo, o «Solo resumen» si no fue posible acceder a él. No afirme resultados del texto completo si solo leyó el resumen.
3. Guarde `trabajo\sintesis_<F>.json`: `[{"doi": "...", "sintesis_breve": "...", "base_evidencia": "Texto completo (URL) | Solo resumen"}]` y ejecute `4_registrar_sintesis.ps1`.
4. Escriba `sintesis\sintesis_<F>.md`: síntesis temática de **todos** los aprobados hasta la fecha (lea la pestaña Aprobados con `comun.ps1` y `Leer-Hoja`), cada afirmación con su `[Rxxxx]`, separando «Según el resumen» de «Según el texto completo», con una sección «Evidencia faltante» y un historial de cambios de la semana (aprobados, rechazados, desacuerdos, lote importado).

## Paso D · Informe
Termine con un resumen breve: aprobados, rechazados, desacuerdos y pendientes de la consolidación; nuevos importados, duplicados, rechazados que reaparecieron y títulos parecidos del lote; síntesis registradas; cualquier error.
