# Reglas de deduplicación (versión 1.1 · 2026-10-10)

La deduplicación se hace en código (`scripts/2_buscar_lote.ps1`), nunca por el modelo de IA.

| Regla | Detalle |
|---|---|
| DOI normalizado | Minúsculas, sin `https://doi.org/` ni `doi:`, sin espacios. Es la clave primaria. |
| Duplicado exacto | Mismo DOI normalizado que un registro en Pendientes o Aprobados: se descarta del lote y se cuenta en la pestaña *Lotes* y en `lotes/lote_<fecha>.csv` (`duplicado_doi_Rxxxx`). |
| Rechazado que reaparece | Mismo DOI que un registro en Rechazados: **no se reabre**; queda como advertencia en *Historial_cambios* y *Lotes* (`reaparecen_rechazados`). |
| Título parecido | Título normalizado (minúsculas, sin tildes ni puntuación) con similitud de Levenshtein ≥ 0,90 y año ±1 respecto de cualquier registro existente: entra a Pendientes con `alerta_duplicado`; nunca se fusiona solo (puede ser preprint y versión publicada). |
| Sin DOI | No se admite (criterio del protocolo). |
| DOI fuera de Crossref | Se descarta (repositorios como Zenodo, preprints). |
| Tipo | Solo `journal-article` según Crossref. |
| Duplicado al aprobar | Si al consolidar ya existe un aprobado con el mismo DOI, el nuevo pasa a Rechazados con motivo «Duplicado de Rxxxx». |
