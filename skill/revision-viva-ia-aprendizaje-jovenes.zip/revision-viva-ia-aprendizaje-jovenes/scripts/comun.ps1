﻿# Funciones compartidas de la revision viva. Se carga con: . "$PSScriptRoot\comun.ps1"
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Web.Extensions

$script:Raiz   = Split-Path -Parent $PSScriptRoot
$script:JS     = New-Object System.Web.Script.Serialization.JavaScriptSerializer
$script:JS.MaxJsonLength = [int]::MaxValue
$script:JS.RecursionLimit = 1000
$script:UTF8   = New-Object System.Text.UTF8Encoding($false)

function Leer-Json([string]$ruta) { $script:JS.DeserializeObject([IO.File]::ReadAllText($ruta, [Text.Encoding]::UTF8)) }
function A-Json($o) {
  if ($null -eq $o) { return 'null' }
  if ($o -is [System.Management.Automation.PSObject]) { $o = $o.BaseObject }
  if ($o -is [string]) { return $script:JS.Serialize($o) }
  if ($o -is [bool]) { return $o.ToString().ToLowerInvariant() }
  if ($o -is [ValueType]) { return $script:JS.Serialize($o) }
  if ($o -is [System.Collections.IDictionary]) {
    $partes = foreach ($key in $o.Keys) { $script:JS.Serialize([string]$key) + ':' + (A-Json $o[$key]) }
    return '{' + (@($partes) -join ',') + '}'
  }
  if ($o -is [System.Collections.IEnumerable]) {
    $partes = foreach ($x in $o) { A-Json $x }
    return '[' + (@($partes) -join ',') + ']'
  }
  return $script:JS.Serialize([string]$o)
}
function Escribir-Json($obj, [string]$ruta) { [IO.File]::WriteAllText($ruta, (A-Json $obj), $script:UTF8) }
$script:Config = Leer-Json (Join-Path $Raiz 'config.json')
$script:Libro  = Join-Path $Raiz $Config['libro']

foreach ($d in 'lotes','trabajo','historial','sintesis') { New-Item -ItemType Directory -Force (Join-Path $Raiz $d) | Out-Null }

# ---------------- Encabezados de las hojas ----------------
$script:EncBase = @('id_ref','lote','doi','titulo','anio','autores','revista','idioma','tipo_verificado',
  'indexacion_detectada','verificar_scopus','acceso_abierto','enlace','resumen','alerta_duplicado',
  'sugerencia_IA','justificacion_IA','cita_del_resumen')
$script:EncDecision = @()
foreach ($rv in $Config['revisores']) { $script:EncDecision += @("decision_$($rv['codigo'])", "motivo_$($rv['codigo'])") }
$script:EncPendientes = $EncBase + $EncDecision + @('estado')
$script:EncAprobados  = $EncBase + $EncDecision + @('fecha_decision','base_evidencia','sintesis_breve','fecha_sintesis')
$script:EncRechazados = $EncBase + $EncDecision + @('fecha_decision','motivo_consolidado')
$script:EncHistorial  = @('fecha_hora','lote','evento','id_ref','doi','detalle')
$script:EncLotes      = @('fecha_lote','fecha_hora_ejecucion','motor','consultas','filtros','registros_evaluados',
  'descartados_tipo_o_sin_doi','duplicados_doi','reaparecen_rechazados','titulos_parecidos','nuevos_a_pendientes',
  'archivo_lote','version_protocolo')

# ---------------- Texto: DOI y titulos ----------------
if (-not ('RevTexto' -as [type])) {
Add-Type -TypeDefinition @"
using System; using System.Text; using System.Globalization;
public static class RevTexto {
  public static string NormTitulo(string s) {
    if (s == null) return "";
    string d = s.ToLowerInvariant().Normalize(NormalizationForm.FormD);
    var sb = new StringBuilder();
    foreach (char c in d) {
      if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark) continue;
      sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
    }
    return string.Join(" ", sb.ToString().Split(new[]{' '}, StringSplitOptions.RemoveEmptyEntries));
  }
  // 1 - distancia de Levenshtein / longitud mayor
  public static double Similitud(string a, string b) {
    int n = a.Length, m = b.Length;
    if (n == 0 && m == 0) return 1.0;
    int[] prev = new int[m + 1], cur = new int[m + 1];
    for (int j = 0; j <= m; j++) prev[j] = j;
    for (int i = 1; i <= n; i++) {
      cur[0] = i;
      for (int j = 1; j <= m; j++) {
        int cost = a[i - 1] == b[j - 1] ? 0 : 1;
        cur[j] = Math.Min(Math.Min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
      }
      var t = prev; prev = cur; cur = t;
    }
    return 1.0 - (double)prev[m] / Math.Max(n, m);
  }
}
"@
}

function Normalizar-Doi([string]$d) {
  if ([string]::IsNullOrWhiteSpace($d)) { return '' }
  $x = $d.Trim().ToLowerInvariant()
  $x = $x -replace '^(https?://)?(dx\.)?doi\.org/', '' -replace '^doi:\s*', ''
  return ($x -replace '\s', '')
}

function Normalizar-Decision([string]$s) {
  $t = [RevTexto]::NormTitulo($s)
  if ($t -match '^(aprob|inclu|acept|si$)') { return 'Aprobar' }
  if ($t -match '^(rechaz|exclu|no$)') { return 'Rechazar' }
  return ''
}

# ---------------- HTTP ----------------
function Obtener-Json([string]$url) {
  for ($i = 1; $i -le 4; $i++) {
    try {
      $r = Invoke-WebRequest $url -UseBasicParsing -TimeoutSec 60 -UserAgent 'RevisionVivaIA/1.0'
      return $script:JS.DeserializeObject([Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()))
    } catch {
      $resp = $_.Exception.Response
      if ($resp -and [int]$resp.StatusCode -eq 404) { return $null }
      Start-Sleep -Seconds (3 * $i)
    }
  }
  throw "No se pudo consultar $url"
}

# ---------------- Scopus (API de Elsevier) ----------------
# La clave vive fuera de Drive: %USERPROFILE%\.revision_viva\scopus.txt
# linea 1 = API key de dev.elsevier.com; linea 2 (opcional) = insttoken
$script:RutaClaveScopus = Join-Path $env:USERPROFILE '.revision_viva\scopus.txt'
function Leer-ClaveScopus {
  if (-not (Test-Path $RutaClaveScopus)) { return $null }
  $l = @(Get-Content $RutaClaveScopus | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $_ -notmatch '^#' })
  if ($l.Count -lt 1) { return $null }
  return @{ key = $l[0]; token = $(if ($l.Count -ge 2) { $l[1] } else { '' }) }
}
function Obtener-Scopus($clave, [string]$consulta, [int]$inicio = 0, [int]$n = 25) {
  $url = "https://api.elsevier.com/content/search/scopus?query=" + [uri]::EscapeDataString($consulta) + "&start=$inicio&count=$n&sort=relevancy&field=prism:doi,dc:title"
  $hd = @{ 'X-ELS-APIKey' = $clave.key; 'Accept' = 'application/json' }
  if ($clave.token) { $hd['X-ELS-Insttoken'] = $clave.token }
  $r = Invoke-WebRequest $url -Headers $hd -UseBasicParsing -TimeoutSec 60
  return $script:JS.DeserializeObject([Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray()))
}

# ---------------- Excel (COM) ----------------
function Abrir-Libro([switch]$SoloLectura) {
  if (-not (Test-Path $Libro)) { throw "No existe el libro $Libro" }
  if (-not $SoloLectura) {
    try { $fs = [IO.File]::Open($Libro, 'Open', 'ReadWrite', 'None'); $fs.Close() }
    catch { throw "El libro esta abierto o bloqueado (cierrelo en Excel en este equipo): $Libro" }
  }
  $xl = New-Object -ComObject Excel.Application
  $xl.Visible = $false; $xl.DisplayAlerts = $false
  $wb = $xl.Workbooks.Open($Libro, 0, [bool]$SoloLectura)
  return @{ xl = $xl; wb = $wb }
}

function Cerrar-Libro($h, [switch]$Guardar) {
  try { if ($Guardar) { $h.wb.Save() }; $h.wb.Close($false) }
  finally {
    $h.xl.Quit()
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($h.xl)
    [GC]::Collect(); [GC]::WaitForPendingFinalizers()
  }
}

function Leer-Hoja($wb, [string]$nombre) {
  $ws = $wb.Worksheets.Item($nombre)
  $nf = $ws.UsedRange.Row + $ws.UsedRange.Rows.Count - 1
  $nc = $ws.UsedRange.Column + $ws.UsedRange.Columns.Count - 1
  $filas = New-Object System.Collections.ArrayList
  if ($nf -lt 2) { return ,$filas }
  $v = $ws.Range($ws.Cells(1, 1), $ws.Cells($nf, $nc)).Value2
  $enc = @(); for ($c = 1; $c -le $nc; $c++) { $enc += [string]$v[1, $c] }
  for ($f = 2; $f -le $nf; $f++) {
    $h = [ordered]@{}; $vacia = $true
    for ($c = 1; $c -le $nc; $c++) {
      $val = $v[$f, $c]; $s = if ($null -eq $val) { '' } else { [string]$val }
      if ($s -ne '') { $vacia = $false }
      if ($enc[$c - 1]) { $h[$enc[$c - 1]] = $s }
    }
    if (-not $vacia) { [void]$filas.Add($h) }
  }
  return ,$filas
}

function Escribir-Hoja($wb, [string]$nombre, [string[]]$enc, $filas) {
  $ws = $wb.Worksheets.Item($nombre)
  $nfOld = $ws.UsedRange.Row + $ws.UsedRange.Rows.Count - 1
  $ncOld = $ws.UsedRange.Column + $ws.UsedRange.Columns.Count - 1
  if ($nfOld -ge 2) { [void]$ws.Range($ws.Cells(2, 1), $ws.Cells($nfOld, [Math]::Max($ncOld, $enc.Count))).ClearContents() }
  $n = @($filas).Count
  $arr = New-Object 'object[,]' ($n + 1), $enc.Count
  for ($c = 0; $c -lt $enc.Count; $c++) { $arr[0, $c] = $enc[$c] }
  for ($r = 0; $r -lt $n; $r++) {
    for ($c = 0; $c -lt $enc.Count; $c++) {
      $s = [string]$filas[$r][$enc[$c]]
      if ($s.Length -gt 32000) { $s = $s.Substring(0, 32000) }
      $arr[($r + 1), $c] = $s
    }
  }
  $rng = $ws.Range($ws.Cells(1, 1), $ws.Cells($n + 1, $enc.Count))
  $rng.NumberFormat = '@'
  $rng.Value2 = $arr
}

function Agregar-Historial($lista, [string]$lote, [string]$evento, [string]$id, [string]$doi, [string]$detalle) {
  [void]$lista.Add([ordered]@{ fecha_hora = (Get-Date -Format 'yyyy-MM-dd HH:mm'); lote = $lote; evento = $evento; id_ref = $id; doi = $doi; detalle = $detalle })
}

function Siguiente-Id($wb) {
  $max = 0
  foreach ($h in 'Pendientes','Aprobados','Rechazados') {
    foreach ($f in (Leer-Hoja $wb $h)) { if ($f['id_ref'] -match '^R(\d+)$') { $max = [Math]::Max($max, [int]$Matches[1]) } }
  }
  return $max + 1
}

function Formatear-Libro($wb) {
  foreach ($ws in $wb.Worksheets) {
    $ur = $ws.UsedRange
    $enc = $ws.Range($ws.Cells(1, 1), $ws.Cells(1, $ur.Columns.Count))
    $enc.Font.Bold = $true; $enc.Interior.Color = 0x6B3A1F; $enc.Font.Color = 0xFFFFFF
    $ws.Activate(); $wb.Application.ActiveWindow.FreezePanes = $false
    $wb.Application.ActiveWindow.SplitRow = 1; $wb.Application.ActiveWindow.SplitColumn = 0
    $wb.Application.ActiveWindow.FreezePanes = $true
    if ($ws.Name -ne 'Protocolo' -and $ws.Name -ne 'Instrucciones') {
      if ($ws.AutoFilterMode) { $ws.AutoFilterMode = $false }
      [void]$ur.AutoFilter()
    }
    [void]$ws.Columns.AutoFit()
    for ($c = 1; $c -le $ur.Columns.Count; $c++) { if ($ws.Columns($c).ColumnWidth -gt 60) { $ws.Columns($c).ColumnWidth = 60 } }
    [void]$ws.Rows.AutoFit()
    $ws.Rows.RowHeight = 15
    $ws.Rows(1).RowHeight = 20
  }
  # Listas desplegables de decision y resaltado en Pendientes
  $ws = $wb.Worksheets.Item('Pendientes')
  foreach ($rv in $Config['revisores']) {
    $col = [array]::IndexOf($EncPendientes, "decision_$($rv['codigo'])") + 1
    $rng = $ws.Range($ws.Cells(2, $col), $ws.Cells(3000, $col))
    $rng.Validation.Delete()
    [void]$rng.Validation.Add(3, 1, 1, 'Aprobar,Rechazar')
    $rng.Validation.InputTitle = $rv['nombre']; $rng.Validation.InputMessage = 'Elija Aprobar o Rechazar y escriba el motivo en la columna siguiente.'
    $ws.Range($ws.Cells(1, $col), $ws.Cells(1, $col + 1)).Interior.Color = 0x2F7D32
    $ws.Columns($col).ColumnWidth = 16; $ws.Columns($col + 1).ColumnWidth = 30
  }
  $wb.Worksheets.Item('Pendientes').Activate()
}
