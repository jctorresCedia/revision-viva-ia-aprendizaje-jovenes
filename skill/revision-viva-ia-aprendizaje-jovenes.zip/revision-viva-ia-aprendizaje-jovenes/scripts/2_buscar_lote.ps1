﻿# Pasos 1-2: ejecuta las cadenas del protocolo en OpenAlex, verifica tipo en Crossref,
# deduplica por DOI normalizado contra toda la coleccion (Pendientes, Aprobados, Rechazados)
# y senala titulos parecidos. Salidas:
#   lotes\lote_<fecha>.csv              exportacion fechada con el resultado de cada registro evaluado
#   trabajo\candidatos_<fecha>.json     registros nuevos que esperan sugerencia de pertinencia
param([string]$Fecha = (Get-Date -Format 'yyyy-MM-dd'))
. "$PSScriptRoot\comun.ps1"
if (Test-Path (Join-Path $Raiz "lotes\lote_$Fecha.csv")) { "YA_EXISTE: el lote $Fecha ya fue importado; no se busca otro hoy. Omita los pasos B y C."; exit 0 }

# ---- Coleccion existente ----
$h = Abrir-Libro -SoloLectura
try {
  $existentes = @{}   # doi -> @{id; hoja}
  $titulos = New-Object System.Collections.ArrayList
  foreach ($hoja in 'Pendientes','Aprobados','Rechazados') {
    foreach ($f in (Leer-Hoja $h.wb $hoja)) {
      $d = Normalizar-Doi $f['doi']
      if ($d) { $existentes[$d] = @{ id = $f['id_ref']; hoja = $hoja } }
      [void]$titulos.Add(@{ id = $f['id_ref']; hoja = $hoja; t = [RevTexto]::NormTitulo($f['titulo']); anio = [int]('0' + $f['anio']) })
    }
  }
  $lotesPrevios = Leer-Hoja $h.wb 'Lotes'
}
finally { Cerrar-Libro $h }
$ultimoLote = ($lotesPrevios | ForEach-Object { $_['fecha_lote'] } | Sort-Object | Select-Object -Last 1)

# ---- Utilidades ----
function Resumen-OpenAlex($inv) {
  if (-not $inv) { return '' }
  $pos = @{}
  foreach ($k in $inv.Keys) { foreach ($p in $inv[$k]) { $pos[[int]$p] = $k } }
  return (($pos.Keys | Sort-Object | ForEach-Object { $pos[$_] }) -join ' ')
}
function Limpiar-Jats([string]$s) { if (-not $s) { return '' }; return (($s -replace '<[^>]+>', ' ') -replace '\s+', ' ').Trim() -replace '^(Abstract|Resumen)\s*', '' }

$campos = 'id,doi,title,publication_year,language,type,primary_location,locations,authorships,open_access,created_date,abstract_inverted_index'
function Url-OpenAlex($q, [string]$extra, [string]$cursor) {
  if ($extra -notmatch 'from_publication_date') { $extra = ",from_publication_date:$($Config['anio_desde'])-01-01" + $extra }
  $f = "title_and_abstract.search:" + $q['cadena'] + ",type:article,has_doi:true,is_retracted:false,is_paratext:false,language:" + $q['idioma'] + $extra
  return "https://api.openalex.org/works?filter=" + [uri]::EscapeDataString($f) + "&per_page=50&cursor=" + [uri]::EscapeDataString($cursor) + "&select=$campos"
}

$evaluados = New-Object System.Collections.ArrayList
$candidatos = New-Object System.Collections.ArrayList
$vistos = @{}
$cont = @{ tipo = 0; dup = 0; rech = 0; parecidos = 0 }
$reaparecen = @()

function Evaluar($w, [string]$consulta, [string]$via, [string]$enScopus = '') {
  $doi = Normalizar-Doi $w['doi']
  $fila = [ordered]@{ consulta = $consulta; via = $via; doi = $doi; titulo = $w['title']; anio = $w['publication_year']; openalex = $w['id']; resultado = '' }
  [void]$evaluados.Add($fila)
  if (-not $doi -or -not $w['title']) { $fila.resultado = 'descartado_sin_doi_o_titulo'; $cont.tipo++; return }
  if ($vistos.ContainsKey($doi)) { $fila.resultado = 'repetido_en_esta_busqueda'; return }
  $vistos[$doi] = $true
  if ($existentes.ContainsKey($doi)) {
    $e = $existentes[$doi]
    if ($e.hoja -eq 'Rechazados') { $fila.resultado = "reaparece_rechazado_$($e.id)"; $cont.rech++; $script:reaparecen += $e.id }
    else { $fila.resultado = "duplicado_doi_$($e.id)_$($e.hoja)"; $cont.dup++ }
    return
  }
  # Verificacion de tipo en Crossref
  $cr = Obtener-Json ("https://api.crossref.org/works/" + [uri]::EscapeDataString($doi))
  $tipo = ''; $resumenCr = ''
  if ($cr) {
    $tipo = $cr['message']['type']
    if ($tipo -ne 'journal-article') { $fila.resultado = "descartado_tipo_$tipo"; $cont.tipo++; return }
    $tipo = 'journal-article (Crossref)'; $resumenCr = Limpiar-Jats $cr['message']['abstract']
  } else { $fila.resultado = 'descartado_doi_no_crossref (repositorio/preprint)'; $cont.tipo++; return }

  $resumen = Resumen-OpenAlex $w['abstract_inverted_index']
  if ($resumen.Length -lt 100 -and $resumenCr.Length -gt $resumen.Length) { $resumen = $resumenCr }

  # Titulos parecidos (mismo anio +-1)
  $t = [RevTexto]::NormTitulo($w['title']); $alertas = @()
  foreach ($x in $titulos) {
    if ([Math]::Abs($x.anio - [int]$w['publication_year']) -le 1 -and $x.t) {
      $s = [RevTexto]::Similitud($t, $x.t)
      if ($s -ge $Config['umbral_titulo_parecido']) { $alertas += "Titulo parecido a $($x.id) ($($x.hoja), similitud $([Math]::Round($s,2)))" }
    }
  }
  if ($alertas) { $cont.parecidos++ }

  $indexa = @()
  $urls = @($w['locations'] | ForEach-Object { $s = $_['source']; "$($_['landing_page_url']) $(if ($s) { $s['display_name'] })" }) -join ' '
  if ($urls -match 'scielo') { $indexa += 'SciELO' }
  if ($urls -match 'redalyc') { $indexa += 'Redalyc' }
  $src = $w['primary_location']['source']
  if ($src -and $src['is_in_doaj']) { $indexa += 'DOAJ' }
  $verifScopus = Verificar-Scopus $doi $enScopus
  if ($verifScopus -like 'Si*') { $indexa = @('Scopus') + $indexa }
  $indexa += 'OpenAlex'

  $oa = $w['open_access']
  $acceso = if ($oa -and $oa['is_oa']) { "Si ($($oa['oa_status'])) $($oa['oa_url'])" } else { 'No / no detectado' }
  $autores = @($w['authorships'] | Select-Object -First 6 | ForEach-Object { $_['author']['display_name'] }) -join '; '
  if (@($w['authorships']).Count -gt 6) { $autores += '; et al.' }

  $fila.resultado = 'nuevo'
  [void]$candidatos.Add([ordered]@{
    doi = $doi; titulo = $w['title']; anio = [string]$w['publication_year']; autores = $autores
    revista = if ($src) { $src['display_name'] } else { '' }; idioma = $w['language']; tipo_verificado = $tipo
    indexacion_detectada = ($indexa -join '; '); verificar_scopus = $verifScopus
    acceso_abierto = $acceso; enlace = "https://doi.org/$doi"
    resumen = if ($resumen) { $resumen } else { 'SIN RESUMEN DISPONIBLE - evidencia insuficiente para juzgar pertinencia' }
    alerta_duplicado = ($alertas -join ' | '); consulta = $consulta; via = $via
  })
}

function Tomados([string]$id) { @($candidatos | Where-Object { $_['consulta'] -eq $id }).Count }

# ---- Scopus: verificacion por DOI y busqueda ----
$clave = Leer-ClaveScopus
$scopusEstado = if ($clave) { 'clave encontrada' } else { "sin clave ($RutaClaveScopus)" }
function Verificar-Scopus([string]$doi, [string]$enScopus) {
  if ($enScopus) { return $enScopus }
  if (-not $script:clave) { return "Pendiente (sin acceso a la API de Scopus: $script:scopusEstado)" }
  try {
    $j = Obtener-Scopus $script:clave "DOI($doi)" 0 1
    if ([int]$j['search-results']['opensearch:totalResults'] -gt 0) { return "Si (verificado en Scopus $Fecha)" }
    return "No encontrado en Scopus ($Fecha)"
  } catch { return "No verificado (error Scopus: $($_.Exception.Message))" }
}
function Recorrer-Scopus($q) {
  $cupo = [int]$q['cupo_scopus']; $tomados = 0
  for ($inicio = 0; $inicio -lt 500; $inicio += 25) {
    if ($tomados -ge $cupo -or $candidatos.Count -ge $Config['tamano_lote']) { return }
    $j = Obtener-Scopus $script:clave $q['cadena_scopus'] $inicio 25
    $ents = @($j['search-results']['entry'] | Where-Object { $_ -and $_['prism:doi'] })
    if (-not $ents) { return }
    foreach ($e in $ents) {
      if ($tomados -ge $cupo -or $candidatos.Count -ge $Config['tamano_lote']) { return }
      $d = Normalizar-Doi $e['prism:doi']
      if ($vistos.ContainsKey($d) -or $existentes.ContainsKey($d)) {
        Evaluar @{ doi = $d; title = $e['dc:title']; id = '' } $q['id'] 'scopus'; continue
      }
      $w = Obtener-Json ("https://api.openalex.org/works/doi:" + $d + "?select=$campos")
      if (-not $w) { [void]$evaluados.Add([ordered]@{ consulta = $q['id']; via = 'scopus'; doi = $d; titulo = $e['dc:title']; anio = ''; openalex = ''; resultado = 'scopus_sin_metadatos_openalex' }); continue }
      $antes = $candidatos.Count
      Evaluar $w $q['id'] 'scopus' "Si (resultado de busqueda en Scopus $Fecha)"
      if ($candidatos.Count -gt $antes) { $tomados++ }
    }
  }
}

function Recorrer($q, [string]$extra, [string]$via, [int]$cupo, [int]$maxPaginas) {
  $cursor = '*'; $tomados = 0
  if ($cupo -le 0) { return }
  for ($p = 1; $p -le $maxPaginas -and $cursor; $p++) {
    $j = Obtener-Json (Url-OpenAlex $q $extra $cursor)
    if (-not $j -or -not $j['results']) { break }
    foreach ($w in $j['results']) {
      if ($tomados -ge $cupo -or $candidatos.Count -ge $Config['tamano_lote']) { return }
      $antes = $candidatos.Count
      Evaluar $w $q['id'] $via
      if ($candidatos.Count -gt $antes) { $tomados++ }
    }
    $cursor = $j['meta']['next_cursor']
    Start-Sleep -Milliseconds 300
  }
}

# 0) Scopus (si hay clave y la red/insttoken es reconocida por Elsevier)
if ($clave) {
  try { foreach ($q in $Config['consultas']) { if ($q['cadena_scopus']) { Recorrer-Scopus $q } }; $scopusEstado = 'busqueda Scopus OK' }
  catch { $scopusEstado = "Scopus no disponible: $($_.Exception.Message)"; $clave = $null }
}
# 1) Novedades: publicadas desde 14 dias antes del lote anterior (from_created_date es de pago en OpenAlex)
if ($ultimoLote) {
  $desde = ([datetime]$ultimoLote).AddDays(-14).ToString('yyyy-MM-dd')
  foreach ($q in $Config['consultas']) { Recorrer $q ",from_publication_date:$desde" 'novedad' ([Math]::Min([int]$Config['cupo_novedades'], [int]$q['cupo'] - (Tomados $q['id']))) 4 }
}
# 2) Busqueda acumulada por relevancia, con cupo por consulta
foreach ($q in $Config['consultas']) { Recorrer $q '' 'relevancia' ([int]$q['cupo'] - (Tomados $q['id'])) 20 }

# ---- Salidas ----
$archivoLote = "lotes\lote_$Fecha.csv"
$evaluados | ForEach-Object { [pscustomobject]$_ } | Export-Csv (Join-Path $Raiz $archivoLote) -NoTypeInformation -Encoding UTF8
$meta = [ordered]@{
  fecha_lote = $Fecha; fecha_hora_ejecucion = (Get-Date -Format 'yyyy-MM-dd HH:mm'); motor = "OpenAlex + Crossref; Scopus: $scopusEstado"
  consultas = (($Config['consultas'] | ForEach-Object { "$($_['id']) OpenAlex: $($_['cadena'])" + $(if ($clave -and $_['cadena_scopus']) { " | $($_['id']) Scopus: $($_['cadena_scopus'])" }) }) -join ' || ')
  filtros = "type:article; has_doi; no retractado; idioma en/es; desde $($Config['anio_desde']); Crossref journal-article" + $(if ($ultimoLote) { "; novedades publicadas desde $desde" } else { '' })
  registros_evaluados = [string]$evaluados.Count; descartados_tipo_o_sin_doi = [string]$cont.tipo; duplicados_doi = [string]$cont.dup
  reaparecen_rechazados = [string]$cont.rech + $(if ($reaparecen) { ' (' + (($reaparecen | Select-Object -Unique) -join ', ') + ')' } else { '' })
  titulos_parecidos = [string]$cont.parecidos; nuevos_a_pendientes = [string]$candidatos.Count
  archivo_lote = $archivoLote; version_protocolo = $Config['version_protocolo']
}
Escribir-Json ([ordered]@{ meta = $meta; candidatos = @($candidatos) }) (Join-Path $Raiz "trabajo\candidatos_$Fecha.json")
"Lote $Fecha -> evaluados $($evaluados.Count), nuevos $($candidatos.Count), duplicados DOI $($cont.dup), rechazados que reaparecen $($cont.rech), descartados por tipo $($cont.tipo), titulos parecidos $($cont.parecidos)"
"Scopus: $scopusEstado"
"Candidatos: trabajo\candidatos_$Fecha.json"
