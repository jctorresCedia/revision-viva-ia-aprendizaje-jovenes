﻿# Crea el libro de la revision viva (solo la primera vez).
. "$PSScriptRoot\comun.ps1"
if (Test-Path $Libro) { throw "El libro ya existe: $Libro" }

$xl = New-Object -ComObject Excel.Application
$xl.Visible = $false; $xl.DisplayAlerts = $false
$wb = $xl.Workbooks.Add()
while ($wb.Worksheets.Count -lt 7) { [void]$wb.Worksheets.Add([Type]::Missing, $wb.Worksheets.Item($wb.Worksheets.Count)) }
$nombres = 'Instrucciones','Protocolo','Pendientes','Aprobados','Rechazados','Historial_cambios','Lotes'
for ($i = 0; $i -lt 7; $i++) { $wb.Worksheets.Item($i + 1).Name = $nombres[$i] }
$wb.SaveAs($Libro, 51)
$h = @{ xl = $xl; wb = $wb }

$rev = ($Config['revisores'] | ForEach-Object { "$($_['nombre']) ($($_['codigo']))" }) -join ' y '
$instr = @(
  @{ Paso = '1'; Que = 'Cada sabado, antes de las 9:00 pm (hora de Ecuador), cada revisor abre la hoja Pendientes.' },
  @{ Paso = '2'; Que = "Revisores: $rev. Cada uno usa SOLO sus columnas verdes: decision_<codigo> (Aprobar/Rechazar) y motivo_<codigo>." },
  @{ Paso = '3'; Que = 'Lea el resumen y abra el enlace. La sugerencia_IA es solo una propuesta basada en el resumen: la decision es humana.' },
  @{ Paso = '4'; Que = 'Regla de consenso AMBOS: un registro se incorpora solo cuando los dos revisores deciden lo mismo. Si falta uno queda Pendiente; si discrepan queda en Desacuerdo para conciliar.' },
  @{ Paso = '5'; Que = 'Cierre el archivo antes de las 10:00 pm. A esa hora el proceso automatico mueve los decididos a Aprobados o Rechazados, registra fecha y revisores en Historial e importa el lote nuevo.' },
  @{ Paso = '6'; Que = 'No borre filas ni cambie encabezados. Los rechazados se conservan para que no reaparezcan sin advertencia.' },
  @{ Paso = '7'; Que = 'alerta_duplicado senala titulos parecidos a registros existentes: revise y decida; nunca se fusionan solos.' },
  @{ Paso = '8'; Que = 'verificar_scopus: la indexacion en Scopus no se puede comprobar sin acceso institucional; verifiquela en Scopus (UTE) si es criterio decisivo.' }
)
Escribir-Hoja $wb 'Instrucciones' @('Paso','Que') $instr

$prot = @(
  @{ Campo = 'Version del protocolo'; Valor = $Config['version_protocolo'] },
  @{ Campo = 'Fecha de inicio'; Valor = '2026-10-10' },
  @{ Campo = 'Pregunta'; Valor = 'Cual ha sido el impacto del uso de herramientas de inteligencia artificial (IA generativa, chatbots, tutores inteligentes, sistemas adaptativos) en las capacidades de aprendizaje de adolescentes y jovenes?' },
  @{ Campo = 'Poblacion'; Valor = 'Adolescentes y jovenes de 12 a 29 anos, incluidos estudiantes de secundaria/bachillerato y de educacion superior.' },
  @{ Campo = 'Exposicion'; Valor = 'Uso de herramientas de IA por parte de los propios estudiantes/jovenes en procesos de aprendizaje.' },
  @{ Campo = 'Resultados'; Valor = 'Capacidades de aprendizaje: rendimiento o logro academico, aprendizaje de contenidos, pensamiento critico, resolucion de problemas, escritura, autorregulacion, metacognicion, motivacion/compromiso, creatividad, dependencia o descarga cognitiva.' },
  @{ Campo = 'Tipo de estudio'; Valor = 'Articulos academicos en revistas con DOI: estudios empiricos (cuantitativos, cualitativos, mixtos), revisiones sistematicas y metaanalisis.' },
  @{ Campo = 'Exclusiones'; Valor = 'Libros, capitulos, tesis, actas de congreso, preprints, editoriales y ensayos de opinion sin datos; IA usada solo por docentes o instituciones (p. ej. prediccion de rendimiento) sin efecto estudiado sobre el aprendizaje; poblaciones exclusivamente menores de 12 o mayores de 29 anos; registros sin DOI.' },
  @{ Campo = 'Anios'; Valor = "$($Config['anio_desde']) en adelante" },
  @{ Campo = 'Idiomas'; Valor = 'Ingles y espanol' },
  @{ Campo = 'Fuentes declaradas'; Valor = 'Scopus, Redalyc, SciELO, Google Academico.' },
  @{ Campo = 'Motor de busqueda automatica'; Valor = 'OpenAlex (indice abierto que agrega Crossref, SciELO, Redalyc, DOAJ y repositorios; cobertura comparable a Google Academico). Google Academico no ofrece API y no se consulta automaticamente. Scopus requiere clave institucional: columna verificar_scopus.' },
  @{ Campo = 'Verificacion de tipo'; Valor = 'Cada DOI se consulta en Crossref: solo se aceptan journal-article. Si el DOI no esta en Crossref se acepta el tipo article de OpenAlex y se anota.' },
  @{ Campo = 'Revisores'; Valor = $rev },
  @{ Campo = 'Regla de consenso'; Valor = $Config['regla_consenso'] },
  @{ Campo = 'Frecuencia'; Valor = 'Semanal: revision humana hasta sabado 9:00 pm; actualizacion automatica sabado 10:00 pm (hora de Ecuador, UTC-5).' },
  @{ Campo = 'Tamano de lote'; Valor = "$($Config['tamano_lote']) registros nuevos por semana (hasta $($Config['cupo_novedades']) publicados/indexados desde el lote anterior; el resto de la busqueda acumulada por relevancia)." }
)
foreach ($q in $Config['consultas']) { $prot += @{ Campo = "Cadena $($q['id']) (idioma $($q['idioma']))"; Valor = $q['cadena'] } }
Escribir-Hoja $wb 'Protocolo' @('Campo','Valor') $prot

Escribir-Hoja $wb 'Pendientes' $EncPendientes @()
Escribir-Hoja $wb 'Aprobados'  $EncAprobados  @()
Escribir-Hoja $wb 'Rechazados' $EncRechazados @()
Escribir-Hoja $wb 'Historial_cambios'  $EncHistorial  @([ordered]@{ fecha_hora = (Get-Date -Format 'yyyy-MM-dd HH:mm'); lote = ''; evento = 'PROTOCOLO_CREADO'; id_ref = ''; doi = ''; detalle = "Version $($Config['version_protocolo'])" })
Escribir-Hoja $wb 'Lotes'      $EncLotes      @()
Formatear-Libro $wb
$wb.Worksheets.Item('Instrucciones').Columns(2).ColumnWidth = 120
$wb.Worksheets.Item('Protocolo').Columns(2).ColumnWidth = 120
$wb.Worksheets.Item('Instrucciones').Activate()
Cerrar-Libro $h -Guardar
"Libro creado: $Libro"
