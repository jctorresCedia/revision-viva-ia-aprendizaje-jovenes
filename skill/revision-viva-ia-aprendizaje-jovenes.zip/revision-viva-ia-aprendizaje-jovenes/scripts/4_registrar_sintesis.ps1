﻿# Paso 5: registra en Aprobados la sintesis breve verificada de cada articulo aprobado.
# Entrada: trabajo\sintesis_<fecha>.json
#   [ { "doi": "...", "sintesis_breve": "...", "base_evidencia": "Resumen | Texto completo (URL)" } ]
param([string]$Fecha = (Get-Date -Format 'yyyy-MM-dd'))
. "$PSScriptRoot\comun.ps1"

$ruta = Join-Path $Raiz "trabajo\sintesis_$Fecha.json"
if (-not (Test-Path $ruta)) { "No hay sintesis para $Fecha"; return }
$sin = @{}; foreach ($s in (Leer-Json $ruta)) { $sin[(Normalizar-Doi $s['doi'])] = $s }

$h = Abrir-Libro
try {
  $wb = $h.wb
  $apr = Leer-Hoja $wb 'Aprobados'
  $hist = Leer-Hoja $wb 'Historial_cambios'
  $n = 0
  foreach ($f in $apr) {
    $s = $sin[(Normalizar-Doi $f['doi'])]
    if (-not $s) { continue }
    $f['sintesis_breve'] = $s['sintesis_breve']; $f['base_evidencia'] = $s['base_evidencia']; $f['fecha_sintesis'] = $Fecha
    Agregar-Historial $hist $Fecha 'SINTESIS_REGISTRADA' $f['id_ref'] $f['doi'] "Base: $($s['base_evidencia'])"
    $n++
  }
  Escribir-Hoja $wb 'Aprobados' $EncAprobados $apr
  Escribir-Hoja $wb 'Historial_cambios' $EncHistorial $hist
  Formatear-Libro $wb
  Cerrar-Libro $h -Guardar; $h = $null
  $hist | ForEach-Object { [pscustomobject]$_ } | Export-Csv (Join-Path $Raiz "historial\historial_$Fecha.csv") -NoTypeInformation -Encoding UTF8
  "Sintesis registradas: $n"
}
finally { if ($h) { Cerrar-Libro $h } }
