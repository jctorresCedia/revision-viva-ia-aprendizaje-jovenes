﻿# Paso 3: une candidatos con las sugerencias de pertinencia de la IA y los agrega a Pendientes.
# Entrada: trabajo\candidatos_<fecha>.json y trabajo\sugerencias_<fecha>.json
#   sugerencias = [ { "doi": "...", "sugerencia_IA": "Incluir|Excluir|Evidencia insuficiente",
#                     "justificacion_IA": "...", "cita_del_resumen": "..." } ]
param([string]$Fecha = (Get-Date -Format 'yyyy-MM-dd'))
. "$PSScriptRoot\comun.ps1"

$cand = Leer-Json (Join-Path $Raiz "trabajo\candidatos_$Fecha.json")
$rutaSug = Join-Path $Raiz "trabajo\sugerencias_$Fecha.json"
$sug = @{}
if (Test-Path $rutaSug) { foreach ($s in (Leer-Json $rutaSug)) { $sug[(Normalizar-Doi $s['doi'])] = $s } }

$h = Abrir-Libro
try {
  $wb = $h.wb
  $pend = Leer-Hoja $wb 'Pendientes'
  $hist = Leer-Hoja $wb 'Historial_cambios'
  $lotes = Leer-Hoja $wb 'Lotes'
  if ($lotes | Where-Object { $_['fecha_lote'] -eq $Fecha }) { throw "El lote $Fecha ya fue agregado." }
  $n = Siguiente-Id $wb
  $agregados = 0
  foreach ($c in $cand['candidatos']) {
    $id = 'R{0:D4}' -f $n; $n++
    $f = [ordered]@{}; foreach ($k in $EncPendientes) { $f[$k] = '' }
    foreach ($k in $c.Keys) { if ($f.Contains($k)) { $f[$k] = [string]$c[$k] } }
    $f['id_ref'] = $id; $f['lote'] = $Fecha; $f['estado'] = 'Pendiente'
    $s = $sug[(Normalizar-Doi $c['doi'])]
    if ($s) { $f['sugerencia_IA'] = $s['sugerencia_IA']; $f['justificacion_IA'] = $s['justificacion_IA']; $f['cita_del_resumen'] = $s['cita_del_resumen'] }
    else { $f['sugerencia_IA'] = 'Sin sugerencia'; $f['justificacion_IA'] = 'La IA no produjo sugerencia para este registro.' }
    [void]$pend.Add($f); $agregados++
    $det = "Sugerencia IA: $($f['sugerencia_IA'])" + $(if ($f['alerta_duplicado']) { ". ALERTA: $($f['alerta_duplicado'])" } else { '' })
    Agregar-Historial $hist $Fecha 'IMPORTADO_A_PENDIENTES' $id $f['doi'] $det
  }
  $m = $cand['meta']
  Agregar-Historial $hist $Fecha 'LOTE_IMPORTADO' '' '' "Evaluados $($m['registros_evaluados']); nuevos $agregados; duplicados DOI descartados $($m['duplicados_doi']); rechazados que reaparecen (no reabiertos) $($m['reaparecen_rechazados']); descartados por tipo $($m['descartados_tipo_o_sin_doi']); titulos parecidos senalados $($m['titulos_parecidos']). Archivo: $($m['archivo_lote'])"
  $filaLote = [ordered]@{}; foreach ($k in $EncLotes) { $filaLote[$k] = [string]$m[$k] }
  [void]$lotes.Add($filaLote)

  Escribir-Hoja $wb 'Pendientes' $EncPendientes $pend
  Escribir-Hoja $wb 'Historial_cambios'  $EncHistorial  $hist
  Escribir-Hoja $wb 'Lotes'      $EncLotes      $lotes
  Formatear-Libro $wb
  Cerrar-Libro $h -Guardar; $h = $null
  $hist | ForEach-Object { [pscustomobject]$_ } | Export-Csv (Join-Path $Raiz "historial\historial_$Fecha.csv") -NoTypeInformation -Encoding UTF8
  "Agregados a Pendientes: $agregados (lote $Fecha). Historial exportado: historial\historial_$Fecha.csv"
}
finally { if ($h) { Cerrar-Libro $h } }
