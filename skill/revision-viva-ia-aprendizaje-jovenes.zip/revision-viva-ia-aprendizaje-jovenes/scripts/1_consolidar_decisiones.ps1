﻿# Paso 4: lee las decisiones de los revisores en Pendientes y mueve los registros decididos
# a Aprobados o Rechazados con revisores y fecha. Escribe trabajo\aprobados_nuevos_<fecha>.json
param([string]$Fecha = (Get-Date -Format 'yyyy-MM-dd'))
. "$PSScriptRoot\comun.ps1"

$h = Abrir-Libro
try {
  $wb = $h.wb
  $pend = Leer-Hoja $wb 'Pendientes'
  $apr  = Leer-Hoja $wb 'Aprobados'
  $rech = Leer-Hoja $wb 'Rechazados'
  $hist = Leer-Hoja $wb 'Historial_cambios'
  $doisApr = @{}; foreach ($f in $apr) { $doisApr[(Normalizar-Doi $f['doi'])] = $f['id_ref'] }

  $quedan = New-Object System.Collections.ArrayList
  $nuevosApr = New-Object System.Collections.ArrayList
  $cont = @{ apr = 0; rech = 0; pend = 0; desac = 0 }

  foreach ($f in $pend) {
    $dec = @{}; $faltan = @()
    foreach ($r in $Config['revisores']) {
      $c = $r['codigo']; $d = Normalizar-Decision $f["decision_$c"]
      if ($d) { $f["decision_$c"] = $d; $dec[$c] = $d } else { $faltan += $r['nombre'] }
    }
    $valores = @($dec.Values | Select-Object -Unique)
    $final = ''
    if ($valores.Count -gt 1) { $f['estado'] = 'Desacuerdo - conciliar' }
    elseif ($valores.Count -eq 1 -and ($faltan.Count -eq 0 -or $Config['regla_consenso'] -eq 'CUALQUIERA')) { $final = $valores[0] }
    elseif ($valores.Count -eq 1) { $f['estado'] = 'Pendiente - falta ' + ($faltan -join ', ') }
    else { $f['estado'] = 'Pendiente' }

    $quienes = ($Config['revisores'] | Where-Object { $dec.ContainsKey($_['codigo']) } | ForEach-Object { "$($_['nombre']): $($dec[$_['codigo']])" }) -join '; '
    $motivos = ($Config['revisores'] | Where-Object { $f["motivo_$($_['codigo'])"] } | ForEach-Object { "$($_['codigo']): $($f["motivo_$($_['codigo'])"])" }) -join ' | '

    if ($final -eq 'Aprobar') {
      $doi = Normalizar-Doi $f['doi']
      if ($doisApr.ContainsKey($doi)) {
        Agregar-Historial $hist $f['lote'] 'DUPLICADO_NO_INCORPORADO' $f['id_ref'] $f['doi'] "Mismo DOI que el aprobado $($doisApr[$doi]); se mueve a Rechazados como duplicado. $quienes"
        $r = [ordered]@{}; foreach ($k in $EncRechazados) { $r[$k] = $f[$k] }
        $r['fecha_decision'] = $Fecha; $r['motivo_consolidado'] = "Duplicado de $($doisApr[$doi])"
        [void]$rech.Add($r); $cont.rech++
        continue
      }
      $r = [ordered]@{}; foreach ($k in $EncAprobados) { $r[$k] = $f[$k] }
      $r['fecha_decision'] = $Fecha
      [void]$apr.Add($r); [void]$nuevosApr.Add($r); $doisApr[$doi] = $f['id_ref']; $cont.apr++
      Agregar-Historial $hist $f['lote'] 'APROBADO' $f['id_ref'] $f['doi'] "$quienes. $motivos"
    }
    elseif ($final -eq 'Rechazar') {
      $r = [ordered]@{}; foreach ($k in $EncRechazados) { $r[$k] = $f[$k] }
      $r['fecha_decision'] = $Fecha; $r['motivo_consolidado'] = $motivos
      [void]$rech.Add($r); $cont.rech++
      Agregar-Historial $hist $f['lote'] 'RECHAZADO' $f['id_ref'] $f['doi'] "$quienes. $motivos"
    }
    else {
      if ($f['estado'] -like 'Desacuerdo*') { $cont.desac++; Agregar-Historial $hist $f['lote'] 'DESACUERDO' $f['id_ref'] $f['doi'] "$quienes. $motivos" } else { $cont.pend++ }
      [void]$quedan.Add($f)
    }
  }

  Agregar-Historial $hist $Fecha 'CONSOLIDACION' '' '' "Aprobados: $($cont.apr); rechazados: $($cont.rech); desacuerdos: $($cont.desac); siguen pendientes: $($cont.pend)"
  Escribir-Hoja $wb 'Pendientes' $EncPendientes $quedan
  Escribir-Hoja $wb 'Aprobados'  $EncAprobados  $apr
  Escribir-Hoja $wb 'Rechazados' $EncRechazados $rech
  Escribir-Hoja $wb 'Historial_cambios'  $EncHistorial  $hist
  Formatear-Libro $wb
  Cerrar-Libro $h -Guardar; $h = $null
  Escribir-Json @($nuevosApr) (Join-Path $Raiz "trabajo\aprobados_nuevos_$Fecha.json")
  "Consolidacion $Fecha -> aprobados $($cont.apr), rechazados $($cont.rech), desacuerdos $($cont.desac), pendientes $($cont.pend)"
}
finally { if ($h) { Cerrar-Libro $h } }
