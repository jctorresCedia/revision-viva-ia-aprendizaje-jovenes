---
name: revision-viva-ia-aprendizaje-jovenes
description: Mantiene la revisión bibliográfica viva de Anai Oñate y Juan Carlos Torres sobre el impacto de la IA en las capacidades de aprendizaje de jóvenes de 12 a 29 años. Cada sábado consolida las decisiones de los dos revisores, busca 15 artículos nuevos en Scopus y OpenAlex, deduplica por DOI, sugiere pertinencia y sintetiza los aprobados. Úsela cuando se mencione la revisión viva de IA y aprendizaje de jóvenes, el lote semanal, la pestaña Pendientes, Aprobados o Rechazados, o los scripts de G:\Mi unidad\Revision_Viva_IA_Aprendizaje_Jovenes.
---

# Revisión viva · IA y capacidades de aprendizaje de jóvenes

Registro que mantiene al día una revisión bibliográfica: importa lotes semanales, deduplica en código, propone inclusiones y deja que **dos personas** decidan. Basado en la guía 10 del curso Vibe Coding CEDIA 2026 (UTE).

Trabaje en español, con trato de usted y tono de colega.

## Datos fijos del proyecto

| Elemento | Valor |
|---|---|
| Carpeta del proyecto | `G:\Mi unidad\Revision_Viva_IA_Aprendizaje_Jovenes` |
| Libro | `Revision_Viva_IA_Aprendizaje_Jovenes.xlsx` (pestañas: Instrucciones, Protocolo, Pendientes, Aprobados, Rechazados, Historial_cambios, Lotes) |
| Pregunta | ¿Cuál ha sido el impacto del uso de herramientas de IA en las capacidades de aprendizaje de adolescentes y jóvenes de 12 a 29 años? |
| Criterios | Artículos de revista con DOI de Crossref (`journal-article`), inglés o español, desde 2020; estudios empíricos, revisiones sistemáticas y metaanálisis |
| Fuentes | Scopus (API de Elsevier, acceso UTE) y OpenAlex (agrega SciELO, Redalyc, DOAJ y Crossref). Google Académico no tiene API |
| Lote | 15 artículos por semana: hasta 10 de Scopus (3 ES + 7 EN) y el resto de OpenAlex (5 ES en total) |
| Revisores | Juan Carlos Torres (JCT) y Anai Oñate (AO). Regla de consenso **AMBOS** |
| Responsable | Anai Oñate. Suplente: Juan Carlos Torres |
| Calendario | Revisión humana hasta el sábado 21:00; ejecución automática el sábado 22:00 (Ecuador, UTC-5) |
| Clave de Scopus | `%USERPROFILE%\.revision_viva\scopus.txt` (línea 1: API key; línea 2 opcional: insttoken). Nunca dentro de Drive ni en el chat |

Los parámetros vivos están en `config.json`; el texto completo, en `references/protocolo.md` y `references/reglas_dedup.md`.

## División del trabajo (regla central)

| Etapa | IA (Claude) | Código, sin IA | Personas |
|---|---|---|---|
| Protocolo | Redacta borradores | — | Fijan criterios y aprueban cada versión |
| Búsqueda | Nada | Ejecuta las cadenas y verifica el tipo en Crossref | Definen cadenas y fuentes |
| Duplicados | Nada | DOI normalizado; títulos parecidos (Levenshtein ≥ 0,90, año ±1) se señalan | Revisan cada alerta |
| Pertinencia | Sugiere Incluir / Excluir / Evidencia insuficiente con cita del resumen | — | Deciden; la sugerencia no es voto |
| Decisión | Nada | Mueve el registro solo si ambos coinciden | JCT y AO aprueban o rechazan con motivo |
| Síntesis | Lee el texto disponible y redacta con `[Rxxxx]` | Registra la síntesis | Comprueban citas en la fuente |

**La IA nunca:** aprueba o rechaza, cambia criterios, edita el Excel fuera de los scripts, borra filas ni da por confirmado un hallazgo que solo leyó en el resumen.

## Ejecución semanal

Siga `references/PROCEDIMIENTO_SEMANAL.md` al pie de la letra. Resumen, con `<F>` = fecha de hoy `yyyy-MM-dd`:

```
powershell -NoProfile -ExecutionPolicy Bypass -File "G:\Mi unidad\Revision_Viva_IA_Aprendizaje_Jovenes\scripts\<script>.ps1" -Fecha <F>
```

1. `1_consolidar_decisiones.ps1` → mueve lo decidido y escribe `trabajo\aprobados_nuevos_<F>.json`.
2. `2_buscar_lote.ps1` → `lotes\lote_<F>.csv` y `trabajo\candidatos_<F>.json`. Si responde `YA_EXISTE`, no se importa otro lote ese día.
3. Escribir `trabajo\sugerencias_<F>.json` (una entrada por candidato: `doi`, `sugerencia_IA`, `justificacion_IA`, `cita_del_resumen`).
4. `3_agregar_pendientes.ps1` → agrega los 15 a Pendientes y exporta el historial.
5. Si hay aprobados nuevos: verificar fuentes, escribir `trabajo\sintesis_<F>.json`, ejecutar `4_registrar_sintesis.ps1` y escribir `sintesis\sintesis_<F>.md`.
6. Informe breve: consolidación, lote, síntesis y errores.

## Reglas operativas

- El libro debe estar cerrado. Si un script dice que está bloqueado, espere 10 minutos y reintente hasta 3 veces; luego deténgase e informe. No cierre el Excel de la persona.
- El script no admite dos lotes con la misma fecha. Un lote extra se programa para otro día como ejecución única; la ejecución ordinaria sigue siendo el sábado.
- Si Scopus no responde (otra red, clave vencida), el lote se completa con OpenAlex y el motivo queda en la pestaña Lotes. Solución: VPN de la UTE o insttoken de la biblioteca.
- Cualquier cambio de pregunta, población, años, idiomas, cadenas, fuentes, tamaño de lote, regla de consenso, revisores, umbral o scripts es una nueva versión: actualice `config.json`, `protocolo.md` (tabla de versiones) y la pestaña Protocolo, y anótelo en el historial.
- En PowerShell `$f` y `$F` son la misma variable: no use `$F` como fecha en scripts que recorren filas con `$f`.
- La hoja de historial se llama `Historial_cambios` porque «Historial» es un nombre reservado en Excel en español.

## Archivos de esta skill

- `scripts/`: copia de los scripts del proyecto (`comun.ps1`, `0_crear_libro.ps1` a `4_registrar_sintesis.ps1`). Los scripts buscan el libro y `config.json` en la carpeta padre de `scripts/`.
- `config.json`: parámetros vigentes (sin clave de Scopus).
- `references/protocolo.md`, `references/reglas_dedup.md`, `references/PROCEDIMIENTO_SEMANAL.md`.

Para reinstalar en una carpeta nueva: copie `scripts/` y `config.json` a la carpeta del proyecto, ejecute `0_crear_libro.ps1` y luego el procedimiento semanal. Requiere Windows con Excel (COM) y PowerShell 5.1; no requiere Python.
